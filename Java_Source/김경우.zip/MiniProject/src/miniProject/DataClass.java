package miniProject;

public class DataClass { // 단순히 data를 담기위한 클래스
   String data1;      // 데이터는 필드에 저장한다
   String data2;
   String data3;
   String data4;
   String data5;
   String data6;
   String data7;
   
}